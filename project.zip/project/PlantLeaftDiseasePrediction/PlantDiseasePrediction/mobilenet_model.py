import tensorflow as tf
from tensorflow.keras.preprocessing import image
from tensorflow.keras.applications.mobilenet import preprocess_input
import numpy as np

# Load the saved model
model = tf.keras.models.load_model("MOBILENET.h5")

class_names=['Pepper__bell___Bacterial_spot', 'Pepper__bell___healthy', 'Potato___Early_blight', 'Potato___Late_blight', 'Potato___healthy', 'Tomato_Bacterial_spot', 'Tomato_Early_blight', 'Tomato_Late_blight', 'Tomato_Leaf_Mold', 'Tomato_Septoria_leaf_spot', 'Tomato_Spider_mites_Two_spotted_spider_mite', 'Tomato__Target_Spot', 'Tomato__Tomato_YellowLeaf__Curl_Virus', 'Tomato__Tomato_mosaic_virus', 'Tomato_healthy']

precautions=["Using pathogen-free seed and disease-free transplants","","Thoroughly spray the plant (bottoms of leaves also) with Bonide Liquid Copper Fungicide concentrate","Late blight is controlled by eliminating cull piles and volunteer potatoes, using proper harvesting and storage practices, and applying fungicides when necessary","","Using pathogen-free seed and disease-free transplants, avoiding sprinkler irrigation and cull piles near greenhouse or field operations, and rotating with a nonhost crop also helps control the disease.","proper fertilization, irrigation, and management of other pests.","Eliminating cull piles and volunteer potatoes, using proper harvesting and storage practices, and applying fungicides when necessary.","avoid wetting the leaves when watering plants, Copper-based fungicides can be used to control tomato leaf mold.","Destroy infested plants by burning or burying them.","Spiromesifen is a synthetic insecticide that can be used to treat spider mites on tomato plants.","sanitation and the application of fungicides","Use a neonicotinoid insecticide, such as dinotefuran (Venom) imidacloprid (AdmirePro, Alias, Nuprid, Widow, and others) or thiamethoxam (Platinum), as a soil application or through the drip irrigation system at transplanting of tomatoes or peppers.","avoid handling plants (plant seed rather than transplants), remove diseased plants, control weeds and rotate crops, and avoid planting near virus-infected plants.",""]


def predict_cataract(img_path):

    # Load and preprocess the image
    img = image.load_img(img_path, target_size=(224, 224))  # Ensure the target_size matches the input size of your model
    x = image.img_to_array(img)
    x = np.expand_dims(x, axis=0)
    x = preprocess_input(x)

    # Make predictions
    predictions = model.predict(x)

    predictions = np.argmax(predictions, axis=1)
    print(class_names[predictions[0]])

    return class_names[predictions[0]],precautions[predictions[0]]