from flask import Flask, request, render_template
from werkzeug.utils import secure_filename
from mobilenet_model import predict_cataract
import os

app = Flask(__name__)

@app.route('/', methods=['GET'])
def index():
    # Main page
    return render_template('index.html')

@app.route('/predict/', methods=['POST'])
def predict():
    if request.method == 'POST':
        f = request.files['file']
        print("in post")
        basepath = os.path.dirname(__file__)
        file_path = os.path.join(
            basepath, 'static\\images', secure_filename(f.filename))
        print("filepath:",file_path)
        f.save(file_path)
        print("after save")
        result,precaution=predict_cataract(file_path)
        return render_template('pred.html',pred=result,f_name=f.filename,precaution=precaution)

    return None


if __name__ == '__main__':
    app.run(debug=True)

